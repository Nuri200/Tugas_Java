/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lingkaran_Lingkaran;

/**
 *
 * @author Nuri Astutik
 */
public class LingkaranLuas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double jarijari = 6;
        double phi = 3.14;
        double LingkaranLuas = phi*jarijari*jarijari;
        System.out.println("jarijari ="+jarijari);
        System.out.println("phi ="+phi);
        System.out.println("Lingkaranluas ="+LingkaranLuas);
    }
    
}
